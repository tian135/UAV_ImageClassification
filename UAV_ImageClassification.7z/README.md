# 基于 ResNet18 的图像分类

## Dataset
- 将`test`、`val`和`train`文件夹放到`.\datase1`下。
- 运行statistic_mean_std.py`完成归一化。

## Train
- 将 `mode = 'train' # infer or train` 中的 mode 改成 train。
- 将 `def get_args_parser()` 内 `--resume` 的default 值修改为空。
- 运行`train.py`
  ```shell
  python train.py
  ```
- 如果要修改训练时的参数，参考`train.py`文件中的`get_args_parser`函数修改默认参数
- 训练过程会在每一个epoch内针对val验证集输出acc1，并在最后输出最大的acc1及对应的epoch。
- 训练完毕后模型文件会被保存到`output_dir_pretrained`下。

## Test
- 将`mode = 'train' # infer or train`改成 infer。
- 将 `def get_args_parser()` 内 `--resume` 的default 值修改为跑出来的模型文件。
- 运行`train.py`
  ```shell
  python train.py
  ```
- 程序会遍历`./test`内的所有图片，并最终输出针对test的acc@1。

## 作者
- **姓名：** 田梓诺
- **班级：** 人工智能1606
- **学号：** 2024E8014682037