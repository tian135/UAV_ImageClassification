# -*- coding = utf-8 -*-

# 统计数据库中所有图片的每个通道的均值和标准差（用于归一化）
import os
import glob
import numpy as np
from PIL import Image

if __name__ == '__main__':
    train_files = glob.glob(os.path.join('train', '*', '*.jpg'))

    print(f'total {len(train_files)} files for training')

    result = []
    for file in train_files:
        img = Image.open(file).convert('RGB')
        img = np.array(img).astype(np.uint8) #0-255
        img = img / 255. #0-1
        result.append(img)

    print(np.shape(result)) # [BS, H, W, C]
    mean = np.mean(result, axis=(0, 1, 2)) #计算图像数据的均值
    std = np.std(result, axis=(0, 1, 2)) #计算图像数据的标准差
    print(mean)
    print(std)
