import argparse
import glob
import math
import os
import random
import sys
import time
from pathlib import Path
import csv
import torch.utils.data
import torchvision.datasets
import timm
from timm.utils import accuracy
from torch.utils.tensorboard import SummaryWriter
from util import misc
from util.misc import NativeScalerWithGradNormCount as NativeScaler
from collections.abc import Iterable
from PIL import Image
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Dataset#
from PIL import Image
import matplotlib.pyplot as plt

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

@torch.no_grad() #禁用梯度计算，节省内存，更高效
def evaluate(data_loader, model, device):
    criterion = torch.nn.CrossEntropyLoss() #交叉熵损失函数
    metric_logger = misc.MetricLogger(delimiter="  ") #自定义日志记录器
    header = 'Test:' #日志输出的标题
    model = model.to(device) #将模型转移到指定的设备
    model.eval() #设为评估模式

    for batch in metric_logger.log_every(data_loader, 10, header): # 遍历数据加载器中的批次数据，每10批次打印1日志
        images = batch[0] #输入图像
        target = batch[-1] #标签
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True) #将输入和标签转移到设备上

        output = model(images) #计算前向传播
        loss = criterion(output, target) #计算输出与标签间的交叉熵损失
        #计算输出每个类别概率分布和准确率
        output = torch.nn.functional.softmax(output, dim=-1)
        acc1 = accuracy(output, target, topk=(1,))
        acc1 = acc1[0].item()  # 提取第一个元素并调用 .item()
        # 更新log日志记录器
        batch_size = images.shape[0]
        metric_logger.update(loss=loss.item()) #更新损失值
        metric_logger.meters['acc1'].update(acc1, n=batch_size)#更新Top-1准确率，按批次大小加权
    #分布式训练时同步多进程的评估结果
    metric_logger.synchronize_between_processes()
    print('* Acc1 {top1.global_avg:.5f} loss {losses.global_avg:.3f}' #losses.global_avg-损失的全局平均值
        .format(top1=metric_logger.acc1, losses=metric_logger.loss))

    #返回一个字典，包含所有评估指标的全局平均值
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}

def train_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    log_writer=None,
                    args=None):
    model.train(True) #设为训练模式
    accum_iter = args.accum_iter #获取梯度累积次数，累积指定次数梯度后再进行一次梯度更新，默认是 1

    #若使用了 TensorBoard 日志记录器，则打印其日志目录
    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    #遍历数据加载器中的批次数据
    for data_iter_step, (samples, targets) in enumerate(data_loader):
        # 将数据移到设备上
        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        outputs = model(samples) #计算前向传播，得到输出

        warmup_lr = args.lr #预热学习率，在训练的初始阶段逐步提高学习率，减小模型开始训练时的震荡
        optimizer.param_groups[0]["lr"] = warmup_lr #更新优化器中第一个参数组的学习率为预热学习率
        #计算损失并进行梯度累积
        loss = criterion(outputs, targets) #计算模型输出与目标标签之间的损失
        loss /= accum_iter
        # 混合精度训练与梯度更新
        loss_scaler(loss, optimizer, clip_grad=max_norm, #防止梯度过大
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0) #达到梯度累积的次数时才更新梯度
        loss_value = loss.item() #获取当前损失值
        # 梯度清零，以进行下一次梯度计算
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()
        #检查损失值是否为有限数，如果损失值异常，停止训练并退出程序
        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            sys.exit(1)
        # 写入TensorBoard日志
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss', loss_value, epoch_1000x)
            log_writer.add_scalar('lr', warmup_lr, epoch_1000x)

def build_transform(is_train, args): #构建数据预处理的 transform 流程，支持训练和验证阶段的不同数据增强策略
    # 训练
    if is_train: #检查 is_train 是否为 True
        print("train transform")
        return torchvision.transforms.Compose([ #顺序执行以下变换
            torchvision.transforms.Resize((args.input_size, args.input_size)),  #调整输入图像大小到网络模型所接受的输入
            torchvision.transforms.RandomPerspective(distortion_scale=0.1, p=0.5), #随机透视变换
            torchvision.transforms.ToTensor() #转换为 PyTorch 张量格式并归一化
        ])
    # 验证
    print("eval transform")
    return torchvision.transforms.Compose([ #验证阶段的数据预处理
        torchvision.transforms.Resize((args.input_size, args.input_size)),
        torchvision.transforms.ToTensor()
    ])

def build_dataset(is_train, args, mode='train'): #构建训练和验证数据集，并使用 ImageFolder 加载图像数据
    transform = build_transform(is_train, args)
    # 拼接路径
    if mode == 'train':
        path = os.path.join(args.root_path, 'train')
    elif mode == 'val':
        path = os.path.join(args.root_path, 'val')
    elif mode == 'test':
        path = os.path.join(args.root_path, 'test')
    else:
        raise ValueError("Invalid mode. Choose from ['train', 'val', 'test'].")
    # 根据文件夹结构自动加载数据集，适用每种类别有一个文件夹的数据集
    dataset = torchvision.datasets.ImageFolder(path, transform=transform) #可以自动识别类别名并相应分配索引
    info = dataset.find_classes(path)  #返回一个包含info0 info1两个元素的元组
    print(f"finding classes from {path}:\t{info[0]}") # 类别名
    print(f"mapping classes from {path} to indexes:\t{info[1]}") # 类别的索引
    return dataset #返回构建好的数据集，ImageFolder 类型

def get_args_parser(): #解析命令行参数，方便用户配置超参数和训练选项
    parser = argparse.ArgumentParser('MAE pre-training', add_help=False) #创建参数解析器
    parser.add_argument('--batch_size', default=72, type=int,
                        help='Batch size per GPU (effective batch size is batch_size * accum_iter * # gpus')
    parser.add_argument('--epochs', default=40, type=int)                  #epoch设置
    parser.add_argument('--accum_iter', default=1, type=int, #梯度累积的次数
                        help='Accumulate gradient iterations (for increasing the effective batch size under memory constraints)')
    # 添加模型输入参数
    parser.add_argument('--input_size', default=32, type=int)
    # 添加优化器参数-权重衰减系数，用于正则化，防止过拟合
    parser.add_argument('--weight_decay', type=float, default=0.0001,
                        help='weight decay (default: 0.0001)')
    #添加学习率参数，绝对学习率
    parser.add_argument('--lr', type=float, default=0.0002, metavar='LR')
    # 添加数据集路径参数，根路径
    parser.add_argument('--root_path', default='dataset1',
                        help='path where to save, empty for no saving')
    #添加输出路径参数
    parser.add_argument('--output_dir', default='./output_dir_pretrained',
                        help='path where to save, empty for no saving')
    parser.add_argument('--log_dir', default='./output_dir_pretrained',
                        help='path where to tensorboard log')
    # 添加模型恢复参数，是否需要加载已有模型(在 pretrained 中)修改
    # parser.add_argument('--resume', default='output_dir_pretrained/checkpoint-39.pth', #infer模式下用这行，将train得到的最佳模型，文件名写到这里
    parser.add_argument('--resume', default='',  #train模式下用这行
                        help='resume from checkpoint')
    #添加起始 epoch 参数，恢复训练时指定从哪个 epoch 开始
    parser.add_argument('--start_epoch', default=0, type=int, metavar='N')
    #添加 DataLoader的工作线程数量，增加可加快数据加载速度
    parser.add_argument('--num_workers', default=5, type=int)
    #固定内存页，以便更高效地将数据从 CPU 传输到 GPU
    parser.add_argument('--pin_mem', action='store_true',
                        help='Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.')
    parser.add_argument('--no_pin_mem', action='store_false', dest='pin_mem')
    parser.set_defaults(pin_mem=True)
    #返回构建好的参数解析器对象，供后续调用
    return parser

def main(args, mode='train', test_image_path=''): #构建数据集、训练模型和评估模型
    print(f"{mode} mode...") #训练or测试模式
    if mode == 'train':
        #构建数据集
        dataset_train = build_dataset(is_train=True, args=args, mode='train')
        dataset_val = build_dataset(is_train=False, args=args, mode='val')
        # 构建数据加载器，训练集打散
        sampler_train = torch.utils.data.RandomSampler(dataset_train)
        sampler_val = torch.utils.data.SequentialSampler(dataset_val)
        data_loader_train = torch.utils.data.DataLoader(
            dataset_train, sampler=sampler_train,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=args.pin_mem,
            drop_last=False
        )
        data_loader_val = torch.utils.data.DataLoader(
            dataset_val, sampler=sampler_val,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=args.pin_mem,
            drop_last=False
        )
        # 构建模型与优化器，基于resnet18实现，若本地无模型缓存需开启vpn下载
        model = timm.create_model('resnet18', pretrained=True, num_classes=2, drop_rate=0.1, drop_path_rate=0.1)
        criterion = torch.nn.CrossEntropyLoss() #交叉熵目标函数
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay) #AdamW 优化器，带有权重衰减
        #初始化日志和模型加载
        os.makedirs(args.log_dir, exist_ok=True)
        log_writer = SummaryWriter(log_dir=args.log_dir) #用于记录训练日志和可视化
        loss_scaler = NativeScaler() #混合精度训练的梯度缩放
        # 训练中断后从已有的模型检查点中加载模型和优化器的状态
        misc.load_model(args=args, model_without_ddp=model, optimizer=optimizer, loss_scaler=loss_scaler)
        # 最大 acc1 与对应的 epoch 记录
        max_acc1 = 0.0
        max_epoch = 0
        epoch_data_list = []  #存储每个 epoch 的训练数据

        for epoch in range(args.start_epoch, args.epochs):
            print(f"Epoch {epoch}")
            if epoch % 1 == 0:
                print("评估阶段Evaluating...")
                model.eval() #置为eval模式
                test_stats = evaluate(data_loader_val, model, device) #评估模型性能，返回测试集的精度和损失
                acc1 = test_stats['acc1']
                loss = test_stats['loss']
                # 更新最大 acc1 与对应的 epoch
                if acc1 > max_acc1:
                    max_acc1 = acc1
                    max_epoch = epoch
                # 记录每个 epoch 的数据
                epoch_data = {
                    'epoch': epoch,
                    'acc1': acc1,
                    'loss': loss
                }
                epoch_data_list.append(epoch_data) #将本 epoch 的数据添加到列表

                print(f"Accuracy of the network on the {len(dataset_val)} val images: {test_stats['acc1']:.5f}%")

                if log_writer is not None:
                    # 写入到 tensorboard 中
                    log_writer.add_scalar('perf/test_acc1', test_stats['acc1'], epoch) #单列perf栏
                    log_writer.add_scalar('perf/test_loss', test_stats['loss'], epoch)
                model.train() #还原train模式
            #训练阶段
            print("Training...")
            train_one_epoch(
                model, criterion, data_loader_train,
                optimizer, device, epoch+1,
                loss_scaler, None,
                log_writer=log_writer,
                args=args
            )

            # 保存模型检查点，记录训练状态
            if args.output_dir:
                print("Saving checkpoint...")
                misc.save_model(
                    args=args, model=model, model_without_ddp=model, optimizer=optimizer,
                    loss_scaler=loss_scaler, epoch=epoch
                )

        # 打印最大的测试集 acc1
        print(f"\n训练完成. 最佳Acc1为 {max_acc1:.5f}%  发生于Epoch{max_epoch}")
        # 保存 CSV 数据
        csv_output_file = os.path.join(args.output_dir, "training_results.csv")
        save_to_csv(epoch_data_list, csv_output_file)

    else: #infer模式
        dataset_test = build_dataset(is_train=False, args=args, mode='test')  # 使用test目录
        data_loader_test = torch.utils.data.DataLoader(
            dataset_test,
            batch_size=args.batch_size,
            num_workers=args.num_workers,
            pin_memory=args.pin_mem,
            drop_last=False
        )
        #构建模型与加载权重
        model = timm.create_model('resnet18', pretrained=False, num_classes=2, drop_rate=0.1, drop_path_rate=0.1)
        # class_dict = {'UAV': 0, 'background': 1}
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        os.makedirs(args.log_dir, exist_ok=True)
        loss_scaler = NativeScaler()
        # 训练中断后从已有的模型检查点中加载模型和优化器的状态
        misc.load_model(args=args, model_without_ddp=model, optimizer=optimizer, loss_scaler=loss_scaler)
        model.eval() #置为eval模式
        # 使用测试集评估
        print("Evaluating on the test set...")
        test_stats = evaluate(data_loader_test, model, device)
        print(f"The .pth's acc@1 on the test image is {test_stats['acc1']:.5f}%")
        #以下代码用于输出test中每张图像的预测值，用于针对性查看哪张分类错误，以便调整模型
        # #加载测试图像
        # image = Image.open(test_image_path).convert('RGB')
        # image = image.resize((args.input_size, args.input_size), Image.ANTIALIAS)
        # image = torchvision.transforms.ToTensor()(image).unsqueeze(0)
        # #推理阶段
        # with torch.no_grad():
        #     output = model(image) #禁用梯度计算，以节省显存
        # output = torch.nn.functional.softmax(output, dim=-1)
        # class_idx = torch.argmax(output, dim=1)[0] #找到最大值对应的索引
        # score = torch.max(output, dim=1)[0][0] #找到最大值
        # #打印测试图像路径、预测得分、类别索引以及类别名称
        # print(f"image path is {test_image_path}")
        # print(f"score is {score.item()}, class id is {class_idx.item()}, "
        #       f"class name is {list(class_dict.keys())[list(class_dict.values()).index(class_idx)]}") #根据values反查找key

def save_to_csv(data_list, output_file):
    """
    保存数据为 CSV 文件
    data_list: 包含每个 epoch 数据的字典列表
    output_file: CSV 文件保存路径
    """
    # 定义 CSV 文件的列名
    fieldnames = ['epoch', 'acc1', 'loss']
    # 写入 CSV 文件
    with open(output_file, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for data in data_list:
            writer.writerow(data)
    print(f"CSV结果表格已存放至 {output_file}")

if __name__ == '__main__': 
    #解析命令行参数
    args = get_args_parser()
    args = args.parse_args()
    #创建输出目录
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True) #exist_ok=True 如果目录已存在，不会报错
    #设置运行模式
    mode = 'train' # infer or train
    #根据模式执行主函数
    if mode == 'train':
        main(args, mode=mode)
    else: #推理/测试模式
        #以下注释内容配合main()最后注释部分使用，输出test中每张图片的预测值
        # images = glob.glob('dataset1/test/*/*.jpg')
        # for image in images:
        #     print('\n')
        main(args, mode=mode)
